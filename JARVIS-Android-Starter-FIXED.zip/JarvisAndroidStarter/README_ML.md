# JARVIS Android Starter

**ശ്രദ്ധിക്കുക:** ഇത് install ചെയ്യാവുന്ന APK അല്ല. Android APK നിർമ്മിക്കാൻ വേണ്ട starter source project ആണ്. ഈ പതിപ്പിൽ Malayalam voice input, text-to-speech, അടിസ്ഥാന UI എന്നിവ മാത്രമേ ഉള്ളൂ. Gemini/Sarvam AI, camera vision, WhatsApp automation, reminders, screen analysis എന്നിവ ഇനിയും ചേർത്തിട്ടില്ല.

## APK ഉണ്ടാക്കാനുള്ള എളുപ്പവഴി (GitHub Actions)
1. GitHub-ൽ പുതിയ repository ഉണ്ടാക്കുക.
2. ഈ ZIP extract ചെയ്ത് ഉള്ളിലെ എല്ലാ ഫയലുകളും repository-യിലേക്ക് upload ചെയ്യുക.
3. Repository തുറന്ന് **Actions** tab തിരഞ്ഞെടുക്കുക.
4. **Build Android APK** workflow തിരഞ്ഞെടുക്കുക. **Run workflow** അമർത്തുക.
5. Build വിജയിച്ചാൽ workflow run തുറന്ന് **Artifacts** ഭാഗത്തുനിന്ന് `JARVIS-Android-debug` download ചെയ്യുക.
6. ZIP തുറന്ന് `app-debug.apk` Android ഫോണിൽ install ചെയ്യാം. ഫോണിൽ ചോദിക്കുന്ന permission മാത്രം അനുവദിക്കുക.

## Android Studio ഉപയോഗിച്ച്
Android Studio-യിൽ ഈ folder തുറക്കുക. Gradle sync പൂർത്തിയാക്കി **Build > Build Bundle(s) / APK(s) > Build APK(s)** തിരഞ്ഞെടുക്കുക.

## സുരക്ഷ
API key ഈ Android app-ൽ നേരിട്ട് ചേർക്കരുത്. യഥാർത്ഥ AI സേവനം ചേർക്കുമ്പോൾ API key server-side backend-ൽ സൂക്ഷിക്കണം. ഈ starter-ൽ API key ഒന്നുമില്ല.

## Build settings
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- compileSdk: 35
- minSdk: 26
