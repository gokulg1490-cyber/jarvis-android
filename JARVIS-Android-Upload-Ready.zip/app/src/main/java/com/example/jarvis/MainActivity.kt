package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var log: TextView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private val voiceRequest = 41
    private val audioPermissionRequest = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(0xFF07111F.toInt())
        }
        val heading = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(0xFF27C7D8.toInt())
        }
        val sub = TextView(this).apply {
            text = "Personal Android Assistant · Starter"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C7D9.toInt())
        }
        log = TextView(this).apply {
            text = "നമസ്കാരം! ഞാൻ JARVIS.\n\nഇപ്പോൾ Voice input, മറുപടി വായിച്ചു കേൾപ്പിക്കൽ എന്നിവയുടെ അടിസ്ഥാന പതിപ്പാണ്. AI connection ഇതിൽ ചേർത്തിട്ടില്ല."
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(14, 18, 14, 18)
        }
        val scroll = ScrollView(this).apply { addView(log) }
        input = EditText(this).apply {
            hint = "ഇവിടെ ടൈപ്പ് ചെയ്യുക"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AAABD.toInt())
            setSingleLine(true)
        }
        val send = Button(this).apply {
            text = "Send"
            setOnClickListener { respond(input.text.toString()) }
        }
        val speak = Button(this).apply {
            text = "🎙 സംസാരിക്കുക"
            setOnClickListener { startVoiceInput() }
        }
        root.addView(heading)
        root.addView(sub)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(input)
        root.addView(send)
        root.addView(speak)
        setContentView(root)
    }

    private fun respond(message: String) {
        if (message.isBlank()) return
        val reply = "നിങ്ങൾ പറഞ്ഞത്: $message\n\nഇത് starter പതിപ്പാണ്. യഥാർത്ഥ AI മറുപടിക്ക് സുരക്ഷിതമായ backend API connection ചേർക്കണം."
        log.append("\n\nനിങ്ങൾ: $message\n\nJARVIS: $reply")
        tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        input.setText("")
    }

    private fun startVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ml-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "സംസാരിക്കുക")
        }
        try { startActivityForResult(intent, voiceRequest) }
        catch (_: Exception) { log.append("\n\nVoice input ഈ ഫോണിൽ ലഭ്യമല്ല.") }
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(words)
            if (words.isNotBlank()) respond(words)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startVoiceInput()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ml", "IN")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
