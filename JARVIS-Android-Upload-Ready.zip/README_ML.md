# JARVIS Android — GitHub APK Build

ഇത് APK അല്ല; APK ഉണ്ടാക്കാനുള്ള Android source project ആണ്.

## ചെയ്യേണ്ടത്
1. ZIP extract ചെയ്യുക.
2. ZIP-ൽ കാണുന്ന `app` ഫോൾഡറും `.github` ഫോൾഡറും കൂടാതെ `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties` എന്നിവ GitHub repository-യുടെ root-ലേക്ക് upload ചെയ്യുക.
3. GitHub repository → Actions → **Build JARVIS Android APK** → **Run workflow**.
4. Build വിജയിച്ചാൽ run തുറന്ന് Artifacts-ൽ നിന്ന് `JARVIS-Android-debug` download ചെയ്യുക.
5. ആ ZIP തുറന്ന് `app-debug.apk` install ചെയ്യുക.

ഈ പതിപ്പിൽ Java compile target, Kotlin JVM target എന്നിവ 17 ആക്കി ക്രമീകരിച്ചിട്ടുണ്ട്. GitHub Actions Gradle 8.9 ഉപയോഗിക്കും.

## ശ്രദ്ധിക്കുക
ഇത് starter app ആണ്. Malayalam voice input, text-to-speech, അടിസ്ഥാന UI എന്നിവ മാത്രമേ നിലവിൽ ഉള്ളൂ. Gemini/Sarvam പോലുള്ള AI backend ഇതിൽ ബന്ധിപ്പിച്ചിട്ടില്ല. API key APK-യിൽ നേരിട്ട് ചേർക്കരുത്.
